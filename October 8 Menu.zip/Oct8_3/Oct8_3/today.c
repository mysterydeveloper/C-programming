/*
 *  today.c - stuff for today :)
 */

#include <stdio.h>
#include <stdlib.h>

float calcBMI(float, float);
void othermain();

void othermain()
{
	float h, w, bmi;

	printf("\n\nEnter your height (m): ");
	fflush(stdin);
	scanf("%f", &h);

	printf("\n\nEnter your weight (kg): ");
	fflush(stdin);
	scanf("%f", &w);

	bmi = calcBMI(h, w);
	printf("\n\nYour BMI is %5.2f.", bmi);

	printf("\n\n\n");
	system("pause");
} // end main

float calcBMI(float height, float weight)
{
	float result;

	result = weight / ( height * height );

	return(result);
} // end of calcBMI