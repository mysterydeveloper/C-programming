/*
 * menu.c - reuseable menu
 */

#include <stdio.h>
#include <stdlib.h>

int showMenu();
void getHeightWeight();
float calcBMI(float, float);

main()
{
	int iChoice;
	
	do
	{
		switch(iChoice = showMenu())
		{
			case 1:
				{
					// calculate bmi
					getHeightWeight();
					break;
				}
			case 2:
				{
					break;
				}
			case 3:
				{
					break;
				}
			case 4:
			default:
			{
				printf("\n\nFugedaboudid");
				break;
			}
		} // end switch
	}while (iChoice != 4);

	printf("\n\n\n");
	system("pause");
} // end main

int showMenu()
{
	int iChoice;

	do
	{
		system("cls");
		printf("\n\n\t\tACME Menus");
		printf("\n\n\t1. Calculate BMI");
		printf("\n\n\t2. Do That");
		printf("\n\n\t3. Do The Other");
		printf("\n\n\t4. Exit");

		printf("\n\nEnter a valid option: ");
		fflush(stdin);
		scanf("%d", &iChoice);
	}while( (iChoice < 0) || (iChoice > 4) );

	return(iChoice);
} // end showMenu

void getHeightWeight()
{
	float h, w, bmi;

	printf("\n\nEnter your height (m): ");
	fflush(stdin);
	scanf("%f", &h);

	printf("\n\nEnter your weight (kg): ");
	fflush(stdin);
	scanf("%f", &w);

	bmi = calcBMI(h, w);
	printf("\n\nYour BMI is %5.2f.", bmi);

	printf("\n\n\n");
	system("pause");
} // end main

float calcBMI(float height, float weight)
{
	float result;

	result = weight / ( height * height );

	return(result);
} // end of calcBMI