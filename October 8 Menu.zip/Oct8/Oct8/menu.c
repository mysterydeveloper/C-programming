/*
 * re-useable menu system
 *		show a number of options
 *		get an input off the user
 *		execute some function
 *		show the menu again
 */

#include <stdio.h>
#include <stdlib.h>

int showMenu();
void getInputForCalcPower();
int calcPower(int , int);

main()
{
	int iChoice;

	// want to show this until the users says exit.

	do
	{
		switch(iChoice = showMenu())
		{
		case 1:	// calculate power
			{
			  getInputForCalcPower();
			  break;
			}
		case 2:
			{
			  break;
			}
		case 3:
			{
				break;
			}
		case 4:
		default:
			{
				printf("\n\nGoodbye Cruel World");
				break;
			}
		} // end switch
	} while( iChoice != 4 ); // end while


	printf("\n\n\n");
	system("pause");
} // end main.

int showMenu()
{
	int iChoice;

	do
	{
		system("cls");
		printf("\n\n\t\tBest Menu Ever");
		printf("\n\n\t1: Calculate Power of a Number");
		printf("\n\n\t2: Do More Stuff");
		printf("\n\n\t3: Do Even More Stuff");
		printf("\n\n\t4: Exit");

		printf("\n\n\n\tEnter a valid choice: ");
		fflush(stdin);
		scanf("%d", &iChoice);
	}while( (iChoice < 1) || (iChoice > 4) );

	return(iChoice);
} // end showMenu

void getInputForCalcPower()
{
	int ans;
	int x, y;

	printf("\nEnter x: ");
	fflush(stdin);
	scanf("%d", &x);

	printf("\nEnter power y: ");
	fflush(stdin);
	scanf("%d", &y);

	ans = calcPower(x, y);
	printf("\n\n%d to the power of %d is %d.", x, y, ans);
	printf("\n\n\n");
	system("pause");
} // void getInputForCalcPower();

int calcPower(int base , int pow)
{
	int result;
	int i;
	// now what?
	// base * base for pow number of time

	if( pow == 0)
	{
		result = 1;
	}
	else if ( pow == 1)
	{
		result = base;
	}
	else
	{
		result = base;
		// loop to find the answer (ask smarties)
		for( i = 2; i <= pow; i++ )
		{
			result *= base;
			//result = result * base;
		}
	}


	return(result);
} // end calcPower