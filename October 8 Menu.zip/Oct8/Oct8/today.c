/*
 * today.c - stuff for today
 */

#include <stdio.h>
#include <stdlib.h>

long int calcPower(int , int);

main()
{
	long int ans;
	int x, y;

	printf("\nEnter x: ");
	fflush(stdin);
	scanf("%d", &x);

	printf("\nEnter power y: ");
	fflush(stdin);
	scanf("%d", &y);

	ans = calcPower(x, y);
	printf("\n\n%d to the power of %d is %d.", x, y, ans);
	printf("\n\n\n");
	system("pause");
} // end main

long int calcPower(int base , int pow)
{
	long int result;
	int i;
	// now what?
	// base * base for pow number of time

	if( pow == 0)
	{
		result = 1;
	}
	else if ( pow == 1)
	{
		result = base;
	}
	else
	{
		result = base;
		// loop to find the answer (ask smarties)
		for( i = 2; i <= pow; i++ )
		{
			result *= base;
			//result = result * base;
		}
	}


	return(result);
} // end calcPower