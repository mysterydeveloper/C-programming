/*
 *	menu.c - a reuseable menu
 */

#include <stdio.h>
#include <stdlib.h>

#define NumMainMenuItems 4	// declare constant

int showMenu();
void getHeightWeight();
float calcBMI(float, float);

main()
{
	int iChoice;

	do
	{
		switch(iChoice = showMenu())
		{
			case 1:
				{
					getHeightWeight();
					break;
				}
			case 2:
			case 3:
			case 4:
			default:
			{
				printf("\n\nGood Afternoon, Good evening and good night");
				break;
			}
		} // end switch
	}while(iChoice != 4);

	printf("\n\n\n");
	system("pause");
}  // end main

int showMenu()
{
	int iChoice;

	do
	{
		system("cls");
		printf("\n\n\t\tBest Menu Ive never seen");
		printf("\n\n\t1: Calculate BMI");
		printf("\n\n\t2: Do More Stuff");
		printf("\n\n\t3: Do Even More Stuff");
		printf("\n\n\t4: Exit");

		printf("\n\nPlease enter a valid choice: ");
		fflush(stdin);
		scanf("%d", &iChoice);
	}while( (iChoice < 0) || (iChoice > NumMainMenuItems) );

	return(iChoice);
} // end showMenu

void getHeightWeight()
{
	float h, w, bmi;

	printf("\n\nEnter your height (m): ");
	fflush(stdin);
	scanf("%f", &h);

	printf("\nEnter your weight (kg): ");
	fflush(stdin);
	scanf("%f", &w);

	bmi = calcBMI(h, w);
	printf("\n\nYour BMI is %5.2f.", bmi);

	printf("\n\n\n");
	system("pause");
} // getHeightWeight

float calcBMI(float height, float weight)
{
	float result;

	result = weight / (height * height);

	return(result);
} // end calcBMI

