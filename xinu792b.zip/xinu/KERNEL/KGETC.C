/* kgetc.c - kgetc */

#include <conf.h>
#include <kernel.h>
#include <tty.h>
#include <kbdio.h>

/*------------------------------------------------------------------------
 *  kgetc  --  get the next character from the keyboard
 *------------------------------------------------------------------------
 */
int kgetc(int d) {
int ch;

  d = d;
  while ((ch = kbdgetc()) == NOCH)  ;

  return ch == RETURN ? NEWLINE : ch;
  }
