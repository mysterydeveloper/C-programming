/* kputc.c - kputc */

#include <conf.h>
#include <kernel.h>
#include <tty.h>
#include <vidio.h>


/*------------------------------------------------------------------------
 *  kputc  --  put a character to the video display
 *  d -- dummy parameter
 * ch -- character to display
 *-----------------------------------------------------------------------*/

int kputc(int d, char ch) {
    d = d;

    if ( ch==RETURN || ch==NEWLINE ) { /* expand newline        */
        ch = NEWLINE;
        wtty(RETURN);
    }
    wtty(ch); return 0;
}
