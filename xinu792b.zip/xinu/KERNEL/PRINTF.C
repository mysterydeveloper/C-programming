/* printf.c - printf */

#include <conf.h>
#include <kernel.h>
#include <io.h>


/*------------------------------------------------------------------------
 *  printf  --  write formatted output to STDOUT
 *-----------------------------------------------------------------------*/

SYSCALL printf(va_dcl, ...) {
va_list ap;
char*   fmt;

  va_start(ap); fmt = va_arg(ap, char*);

  _doprnt(fmt, &va_arg(ap, long), putc, STDOUT);

  return OK;
  }
