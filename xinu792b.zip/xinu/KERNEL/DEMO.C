// Demo program


#include "conf.h"
#include "butler.h"
#include "kernel.h"
#include "window.h"
#include "utils.h"


static int  lu;
static int  producedSem;
static int  consumedSem;
static int  ttySem;

static int  consPid;
static int  prodPid;
static int  dancPid;

static int  portId;

static long n = 0;


// Local Functions

static void consumer(void);
static void producer(void);
static void dancingDot(long ch);
static void mvCurTo(int win, Byte row, Byte col);


// main for application

int xmain(long argc, char* argv[]) {
int  i;

  lu = getdev("tty");

  if (open(lu, "#0,0:79,24", "wht/blu") == SYSERR)
             {kprintf("Unable to open display\n"); sendf(butlerpid, MSGKILL);}

  srand(1243);

  producedSem = screate(1); consumedSem = screate(0); ttySem = screate(1);

  portId = pcreate(3);

  wait(ttySem); close(lu);

    printf("nargs: %d", argc);

    for (i = 0; i < argc; i++) printf(" %s", argv[i]);

  signal(ttySem);

  consPid = create((Fptr) consumer, 2000, 1, "consumer", 0, 0);
  resume(consPid);
  prodPid = create((Fptr) producer, 2000, 1, "producer", 0, 0); resume(prodPid);

  dancPid = create((Fptr) dancingDot, 2000, 1, "dancing", 1, (void*) 'a');
  resume(dancPid);

  return 0;
  }


static void consumer(void) {
int  i;
long msg;

  for (i = 0; i < 10; i++) {
    wait(producedSem);
      wait(ttySem);
        mvCurTo(lu, 10, i * 3); printf("%2ld", n);
      signal(ttySem);
    signal(consumedSem);
    }

  for (i = 0; i < 10; i++) {
    msg = receive();
    wait(ttySem);
      mvCurTo(lu, 11, i * 3); printf("%2ld", msg);
    signal(ttySem);
    }

  for (i = 0; i < 10; i++) {
    msg = (long) preceive(portId);
    wait(ttySem);
      mvCurTo(lu, 12, i * 3); printf("%2ld", msg);
    signal(ttySem);
    }

  wait(ttySem);
    mvCurTo(lu, 15, 9); printf("press return to continue ");
  signal(ttySem);

  getc(lu); sendf(butlerpid, MSGKILL);
  }


static void producer(void) {
int i;

  for (i = 0; i < 10; i++) {
    wait(consumedSem);
    n++;
    signal(producedSem);
    }

  resched();

  for (i = 0; i < 10; i++) send(consPid, n++);

  for (i = 0; i < 10; i++) psend(portId, (char*) n++);
  }


static void dancingDot(long ch) {
int  lu = getdev("tty");
Byte row = 40, col = 0;

  if (open(lu, "#40,2:79,10", "wht/blk") == SYSERR)
             {kprintf("Unable to open display\n"); sendf(butlerpid, MSGKILL);}

  for (;;) {

    wait(ttySem);

      mvCurTo(lu, row, col); putc(lu, ' ');

      row = rand() % 7 + 3; col = rand() % 40 + 40;

      mvCurTo(lu, row, col); putc(lu, (Byte) ch);

    signal(ttySem); sleep(1);
    }
  }


static void mvCurTo(int win, Byte row, Byte col) {
Cur  cur = cur;

  cur.pos.row = row; cur.pos.col = col;

  control(win, TCCurPos, cur.v, 0);
  }

