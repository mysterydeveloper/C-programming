/* doscall.c - doscall, dos_creat, dos_open, dos_close, dos_read, dos_write,
   dos_lseek, dos_mkdir, dos_mkdirs, dos_rmdir, dos_rmdirs, dos_unlink,
   dos_rename, dos_ffirst, dos_fnext, dos_setdta */

#include <dos.h>
#include <conf.h>
#include <kernel.h>
#include <fserver.h>
#include <string.h>

#define AX(r)       ((r).x.ax)
#define BX(r)       ((r).x.bx)
#define CX(r)       ((r).x.cx)
#define DX(r)       ((r).x.dx)
#define DI(r)       ((r).x.di)
#define CFLAG(r)    ((r).x.cflag)
#define AH(r)       ((r).h.ah)
#define AL(r)       ((r).h.al)
#define BH(r)       ((r).h.bh)
#define BL(r)       ((r).h.bl)
#define CH(r)       ((r).h.ch)
#define CL(r)       ((r).h.cl)
#define DH(r)       ((r).h.dh)
#define DL(r)       ((r).h.dl)
#define DS(r)       ((r).ds)
#define ES(r)       ((r).es)

#define DOS_SETDTA  0x1A
#define DOS_MKDIR   0x39
#define DOS_RMDIR   0x3a
#define DOS_CREAT   0x3c
#define DOS_OPEN    0x3d
#define DOS_CLOSE   0x3e
#define DOS_READ    0x3f
#define DOS_WRITE   0x40
#define DOS_UNLINK  0x41
#define DOS_LSEEK   0x42
#define DOS_FFIRST  0x4E
#define DOS_FNEXT   0x4F
#define DOS_RENAME  0x54


/* alias for converting between longs & 2 ints  */
/* this is highly machine/compiler specific */
/* 8088 longs are stored lowword/highword   */

struct L2I {
    int lowword;
    int highword;
};


// Local Functions

static int doscall(union REGS *regsp, struct SREGS *sregsp);


/*------------------------------------------------------------------------
 *  dos_creat  --  create a dos file
 *  pathname -- DOS filename
 *  mode     -- DOS file mode bits
 *-----------------------------------------------------------------------*/

int dos_creat(char *pathname, int attr) {
    union REGS  regs;
    struct SREGS    sregs;

    segread(&sregs);    /* retrieve the segment registers   */
    DX(regs) = FP_OFF(pathname);
    DS(sregs) = FP_SEG(pathname);
    CX(regs) = attr;
    AH(regs) = DOS_CREAT;
    if ( doscall(&regs,&sregs) )
        return(SYSERR);
    return(AX(regs));       /* return the DOS file handle   */
}

/*------------------------------------------------------------------------
 *  dos_open  --  open a dos file
 *  pathname -- DOS filename
 *  mode     -- DOS file mode bits
 *-----------------------------------------------------------------------*/

int dos_open(char *pathname, int mode) {
    union REGS  regs;
    struct SREGS    sregs;
    segread(&sregs);
    DX(regs) = FP_OFF(pathname);
    DS(sregs) = FP_SEG(pathname);
    AL(regs) = mode;
    AH(regs) = DOS_OPEN;
    if ( doscall(&regs,&sregs) )
        return(SYSERR);
    return(AX(regs));       /* return the DOS file handle   */
}

/*------------------------------------------------------------------------
 *  dos_close  --  close a dos file
 *  fd -- file handle to close
 *------------------------------------------------------------------------
 */
int dos_close(int fd) {
    union REGS  regs;
    struct SREGS    sregs;

    segread(&sregs);
    BX(regs) = fd;
    AH(regs) = DOS_CLOSE;
    if ( doscall(&regs,&sregs) )
        return(SYSERR);
    return(OK);
}

/*------------------------------------------------------------------------
 *  dos_read  --  read from a dos file
 *  fd      -- file handle to read from
 *  buffer  -- destination buffer
 *  count   -- no. of bytes to transfer
 *------------------------------------------------------------------------
 */
int dos_read (int fd, char *buffer, int count) {
    union REGS  regs;
    struct SREGS    sregs;

    segread(&sregs);
    BX(regs) = fd;
    DX(regs) = FP_OFF(buffer);
    DS(sregs) = FP_SEG(buffer);
    CX(regs) = count;
    AH(regs) = DOS_READ;
    if ( doscall(&regs,&sregs) )
        return(SYSERR);
    return(AX(regs));       /* no. of bytes actually read */
}

/*------------------------------------------------------------------------
 *  dos_write  --  write to a dos file
 *  fd      -- file handle to read from
 *  buffer  -- destination buffer
 *  count   -- no. of bytes to transfer
 *-----------------------------------------------------------------------*/

int dos_write (int fd, char *buffer, int count) {
    union REGS  regs;
    struct SREGS    sregs;

    segread(&sregs);
    BX(regs) = fd;
    DX(regs) = FP_OFF(buffer);
    DS(sregs) = FP_SEG(buffer);
    CX(regs) = count;
    AH(regs) = DOS_WRITE;
    if ( doscall(&regs,&sregs) )
        return(SYSERR);
    return(AX(regs));       /* no. of bytes actually written */
}

/*------------------------------------------------------------------------
 *  dos_lseek  --  perform an LSEEK on a dos file
 *  fd      -- file handle
 *  offset  -- offset into file
 *  origin  -- origin of seek - 0=beginning, 1=current, 2=end
 *-----------------------------------------------------------------------*/

long dos_lseek(int fd, long offset, int origin) {
    union   REGS    regs;
    struct  SREGS   sregs;
    register struct L2I *lp;

    segread(&sregs);
    BX(regs) = fd;
    lp = (struct L2I *) &offset;
    CX(regs) = lp->highword;
    DX(regs) = lp->lowword;
    AL(regs) = origin;
    AH(regs) = DOS_LSEEK;
    if ( doscall(&regs,&sregs) )
        return( (long)SYSERR );
    lp->highword = DX(regs);
    lp->lowword  = AX(regs);
    return(offset);
}

/*------------------------------------------------------------------------
 *  dos_setdta  --  set disk transfer area
 *------------------------------------------------------------------------
 */
dos_setdta(buf)
char    *buf;               /* buf to write data into */
{
    union   REGS    regs;
    struct  SREGS   sregs;

    segread(&sregs);
    AH(regs) = DOS_SETDTA;
    DX(regs) = FP_OFF(buf);
    DS(sregs) = FP_SEG(buf);
    if ( doscall(&regs,&sregs) )
        return(SYSERR);
    return(OK);
}
/*------------------------------------------------------------------------
 *  dos_unlink  --  remove a file entry
 *  path  -- directory name
 *-----------------------------------------------------------------------*/

int dos_unlink(char *path) {
    union   REGS    regs;
    struct  SREGS   sregs;

    segread(&sregs);
    DX(regs) = FP_OFF(path);
    DS(sregs) = FP_SEG(path);
    AH(regs) = DOS_UNLINK;
    if ( doscall(&regs,&sregs) )
        return( SYSERR );
    return(OK);
}

/*------------------------------------------------------------------------
 *  dos_mkdir  --  make a directory
 * path -- directory name
 *------------------------------------------------------------------------
 */
int dos_mkdir(char *path) {
    union   REGS    regs;
    struct  SREGS   sregs;

    segread(&sregs);
    DX(regs) = FP_OFF(path);
    DS(sregs) = FP_SEG(path);
    AH(regs) = DOS_MKDIR;
    if ( doscall(&regs,&sregs) )
        return(-AX(regs));
    return(OK);
}

/*------------------------------------------------------------------------
 *  dos_mkdirs  --  make a directory tree
 *  path  -- directory name
 *-----------------------------------------------------------------------*/

int dos_mkdirs(char* path) {
    char    *subdir;
    char    fname[RNAMLEN];
    int ret = OK;

    for (subdir=strchr(path+1, '/') ;
        subdir != NULL ;
        subdir = strchr(subdir+1, '/')) {
        strncpy(fname, path, (int) (subdir-path));
        fname[(int) (subdir-path)] = NULLCH;
        ret = dos_mkdir(fname);
    }
    return(ret);
}

/*------------------------------------------------------------------------
 *  dos_rmdir  --  remove a directory
 * path -- directory name
 *-----------------------------------------------------------------------*/

int dos_rmdir(char *path) {
    union   REGS    regs;
    struct  SREGS   sregs;

    segread(&sregs);
    DX(regs) = FP_OFF(path);
    DS(sregs) = FP_SEG(path);
    AH(regs) = DOS_RMDIR;
    if ( doscall(&regs,&sregs) )
        return(-AX(regs));
    return(OK);
}

/*------------------------------------------------------------------------
 *  dos_rmdirs  -- remove a directory tree
 *  path  -- directory name
 *-----------------------------------------------------------------------*/

int dos_rmdirs(char* path) {
    char    *subdir;
    char    fname[RNAMLEN];

    strncpy(fname, path, sizeof(fname));
    fname[sizeof(fname)-1] = NULLCH;
    while ((subdir=strrchr(fname,'/')) != NULL && subdir != fname) {
        *subdir = NULLCH;
        if (dos_rmdir(fname) < 0)
            return(OK);
    }
    return(OK);
}

/*------------------------------------------------------------------------
 *  dos_rename  --  rename a file entry
 *  path    -- file name
 *  newpath -- file name
 *-----------------------------------------------------------------------*/

int dos_rename(char* path, char* newpath) {
    union   REGS    regs;
    struct  SREGS   sregs;

    segread(&sregs);
    DX(regs) = FP_OFF(path);
    DS(sregs) = FP_SEG(path);
    DI(regs) = FP_OFF(newpath);
    ES(sregs) = FP_SEG(newpath);
    AH(regs) = DOS_RENAME;
    if ( doscall(&regs,&sregs) )
        return(SYSERR);
    return(OK);
}

/*------------------------------------------------------------------------
 *  dos_ffirst  --  find first entry in directory that matches attributes
 *------------------------------------------------------------------------
 */
dos_ffirst(path, attr)
char *path;     /* dir name */
int   attr;     /* attributes */
{
    union   REGS    regs;
    struct  SREGS   sregs;

    segread(&sregs);
    DX(regs) = FP_OFF(path);
    DS(sregs) = FP_SEG(path);
    AH(regs) = DOS_FFIRST;
    CX(regs) = attr;
    if ( doscall(&regs,&sregs) )
        return(-AX(regs));
    return(OK);
}

/*------------------------------------------------------------------------
 *  dos_fnext  --  find next entry in directory
 *------------------------------------------------------------------------
 */
dos_fnext()
{
    union   REGS    regs;
    struct  SREGS   sregs;

    segread(&sregs);
    AH(regs) = DOS_FNEXT;
    if ( doscall(&regs,&sregs) )
        return(-AX(regs));
    return(OK);
}




/*------------------------------------------------------------------------
 *  doscall  --  call a dos function
 *-----------------------------------------------------------------------*/

static int doscall(union REGS *regsp, struct SREGS *sregsp) {
  intdosx(regsp,regsp,sregsp);    /* make the DOS call */
  return CFLAG(*regsp);           /* nonzero return means error */
  }

