/* recvtim.c - recvtim */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include <sleep.h>

/*------------------------------------------------------------------------
 *  recvtim  -  wait to receive a message or timeout and return result
 *-----------------------------------------------------------------------*/

LSYSCALL recvtim(int maxwait) {
struct pentry* pptr;
long           msg;
int            ps;

  if ( maxwait <= 0 ) return(SYSERR);

  disable(ps);
    pptr = &proctab[currpid];

    if ( !pptr->phasmsg ) {                   /* if no message, wait      */
      insertd(currpid, clockq, maxwait); slnempty = TRUE;

      sltop = (int *) &q[q[clockq].qnext].qkey;

      pptr->pstate = PRTRECV; resched();
      }

    if ( pptr->phasmsg ) {msg = pptr->pmsg; pptr->phasmsg = FALSE;}
                                              /* msg. arrived => retrieve it  */
    else msg = TIMEOUT;                       /* still no message => TIMEOUT  */

  restore(ps); return msg;
  }
