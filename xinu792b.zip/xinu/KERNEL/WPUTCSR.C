/* wputcsr.c - wputcsr */

#include <conf.h>
#include <kernel.h>
#include <tty.h>

/*------------------------------------------------------------------------
 *  wputcsr  --  cursor position routine
 *------------------------------------------------------------------------
 */

void wputcsr(struct tty* iptr, Cursor csr) {

  csr.row += iptr->topleft.row; csr.col += iptr->topleft.col;

  putcsrpos(csr, 0);
  }
