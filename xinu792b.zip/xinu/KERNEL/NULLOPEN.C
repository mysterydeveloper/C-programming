/* nullopen.c - nullopen */

#include <conf.h>
#include <kernel.h>


int nullioinit(struct devsw* devptr, int flag)
                                       {devptr = devptr; flag = flag; return 1;}

int nullopen(struct devsw* devptr, char* name, char* mode)
                                {name = name; mode = mode; return devptr->dvnum;}

int nullclose(struct devsw* devptr) {devptr = devptr; return 0;}

int nullseek(struct devsw* devptr, long pos)
                                        {devptr = devptr; pos = pos; return 0;}

int nullread(struct devsw* devptr, char* buf, int count)
                          {devptr = devptr; buf = buf; count = count; return 0;}

int nullwrit(struct devsw* devptr, char* buf, int count)
                                     {devptr = devptr; buf = buf; return count;}

int nullgetc(struct devsw* devptr) {devptr = devptr; return EOF;}

int nullputc(struct devsw* devptr, char ch)
                                          {devptr = devptr; ch = ch; return ch;}

int nullcontrol(struct devsw* devptr, int func, char* addr, char* addr2)
           {devptr = devptr; func = func; addr = addr; addr2 = addr2; return 0;}

