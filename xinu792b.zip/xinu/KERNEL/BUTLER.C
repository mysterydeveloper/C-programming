/* butler.c - butler */

#include <conf.h>
#include <kernel.h>
#include <butler.h>
#include <proc.h>


// Local Functions

static void stopAllProcesses(void);


/*------------------------------------------------------------------------
 *  butler  --  general housekeeping process.  Responds to messages and
 *  takes appropriate actions.  Messages recognized are:
 *      MSGKILL     - kill the system
 *      MSGPSNAP    - print a process table snapshot
 *      MSGTSNAP    - print tty structure snapshot
 *      MSGPSNAP    - print disk snapshot
 *-----------------------------------------------------------------------*/

PROCESS butler(void) {
int  pcx;
long msg;

  immortal(getpid());

  for (;;) {
    msg = receive();

    xdisable(pcx);

    switch (msg) {      /* wait for & get the message   */

      case MSGKILL  : xrestore(pcx); stopAllProcesses(); return;

      case MSGPSNAP : psnap(); break;

      #ifdef Ntty

      case MSGTSNAP : tsnap(); break;

      #endif

      #ifdef Ndsk

      case MSGDSNAP : dsnap(); break;

      #endif
      }

    kprintf("Press any key to continue . . ."); kgetc(0); kprintf("\n");

    xrestore(pcx);
    }
  }


static void stopAllProcesses(void) {
int            i;
struct pentry* pptr;

  for (i = 0; i < NPROC; i++) {

    pptr = &proctab[i];

    if (pptr->pstate != PRCURR && pptr->pstate != PRFREE)
                                                  {pptr->pimmortl = 0; kill(i);}
    }
  }
