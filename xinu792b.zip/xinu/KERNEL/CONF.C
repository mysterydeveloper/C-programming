/* conf.c */
/* (GENERATED FILE: DO NOT EDIT) */

#include <conf.h>
#include <pc.h>			/* generic PC definitions */

/* device independent I/O switch */

struct  devsw   devtab[NDEVS] = {

/*------------------------------------------------------------------------
 * Format of each entry is:
 *
 * dev number, dev name, ref count,
 * init, open, close,
 * read, write, seek,
 * getc, putc, cntl,
 * port addr, dev input vector, dev output vector,
 * input interrupt routine, output interrupt routine,
 * dev i/o block, minor dev number
 *------------------------------------------------------------------------
 */

/* CONSOLE is tty on BIOS */
{0,"tty",-1,
ttyinit,ttyopen,nullclose,
ttyread,ttywrite,nullseek,
ttygetc,ttyputc,ttycntl,
0,KBDVEC|BIOSFLG,0,
ttyiin,ioerr,
NULLPTR,0},

/* GENERIC is tty on WINDOW */
{1,"",0,
lwinit,lwopen,lwclose,
lwread,lwwrite,nullseek,
lwgetc,lwputc,lwcntl,
0,0,0,
ioerr,ioerr,
NULLPTR,1},

/* GENERIC is tty on WINDOW */
{2,"",0,
lwinit,lwopen,lwclose,
lwread,lwwrite,nullseek,
lwgetc,lwputc,lwcntl,
0,0,0,
ioerr,ioerr,
NULLPTR,2},

/* STDIN is sio */
{3,"stdin",-1,
sioinit,sioopen,sioclose,
sioread,siowrite,sioseek,
siogetc,sioputc,siocntl,
0,0,0,
ioerr,ioerr,
NULLPTR,0},

/* STDOUT is sio */
{4,"stdout",-1,
sioinit,sioopen,sioclose,
sioread,siowrite,sioseek,
siogetc,sioputc,siocntl,
0,0,0,
ioerr,ioerr,
NULLPTR,1},

/* STDERR is sio */
{5,"stderr",-1,
sioinit,sioopen,sioclose,
sioread,siowrite,sioseek,
siogetc,sioputc,siocntl,
0,0,0,
ioerr,ioerr,
NULLPTR,2},

/* GENERIC is sio */
{6,"",-1,
sioinit,sioopen,sioclose,
sioread,siowrite,sioseek,
siogetc,sioputc,siocntl,
0,0,0,
ioerr,ioerr,
NULLPTR,3},

/* NULLDEV is null */
{7,"null",-1,
nullioinit,nullopen,nullclose,
nullread,nullwrit,nullseek,
nullgetc,nullputc,nullcontrol,
0,0,0,
ioerr,ioerr,
NULLPTR,0},

/* DOS is dos */
{8,"dos",-1,
nullioinit,msopen,nullclose,
ioerr,ioerr,ioerr,
ioerr,ioerr,mscntl,
0,0,0,
ioerr,ioerr,
NULLPTR,0},

/* GENERIC is mf */
{9,"",0,
mfinit,nullopen,mfclose,
mfread,mfwrite,mfseek,
mfgetc,mfputc,ioerr,
0,0,0,
ioerr,ioerr,
NULLPTR,0},

/* GENERIC is mf */
{10,"",0,
mfinit,nullopen,mfclose,
mfread,mfwrite,mfseek,
mfgetc,mfputc,ioerr,
0,0,0,
ioerr,ioerr,
NULLPTR,1},

/* GENERIC is mf */
{11,"",0,
mfinit,nullopen,mfclose,
mfread,mfwrite,mfseek,
mfgetc,mfputc,ioerr,
0,0,0,
ioerr,ioerr,
NULLPTR,2},

/* GENERIC is mf */
{12,"",0,
mfinit,nullopen,mfclose,
mfread,mfwrite,mfseek,
mfgetc,mfputc,ioerr,
0,0,0,
ioerr,ioerr,
NULLPTR,3}
};
