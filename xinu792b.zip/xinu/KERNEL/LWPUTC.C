/* lwputc.c - lwputc */

#include <conf.h>
#include <kernel.h>
#include <tty.h>
#include <proc.h>

/*------------------------------------------------------------------------
 *  lwputc  --  put a character into a logical window
 *------------------------------------------------------------------------
 */

int lwputc(struct devsw* devptr, char ch) {
struct tty* iptr;
int         ps;
int         seq;

  iptr = &tty[devptr->dvminor];

  disable(ps);

  if (iptr->wstate != LWALLOC) {restore(ps); return SYSERR;}
                                                          /* is window open? */
  seq = iptr->seq; wait(iptr->osem);            /* wait for space in queue  */

  if ( iptr->wstate != LWALLOC || iptr->seq != seq) /* is window still open? */
                                                  {restore(ps); return(SYSERR);}
  iptr->obuff[iptr->ohead++] = ch; ++iptr->ocnt;

  if (iptr->ohead >= OBUFLEN) iptr->ohead = 0;

  send(iptr->oprocnum, TMSGOK);         /* was sendn wake up the tty process  */

  restore(ps); return OK;
  }
