/* create.c - create, newpid */

#include <conf.h>
#include <kernel.h>
#include <io.h>
#include <proc.h>
#include <dos.h>
#include <mem.h>


#define INITF   0x0200  /* initial flag register - set interrupt flag,  */
                        /* clear direction and trap flags       */
#define INITPCX 1       /* set pcxflag                  */

extern  int INITRET();  /* location to return upon termination  */


// Local Function

LOCAL newpid(void);



/*------------------------------------------------------------------------
 *  create  --  create a process to start running a procedure
fptr procaddr;          procedure address
word ssize;             stack size in bytes
short priority;         process priority > 0
char *namep;            name (for debugging)
int nargs;              number of args that follow
int args;               arguments (treated like an array)

 *-----------------------------------------------------------------------*/

SYSCALL create(Fptr procaddr, word ssize, short priority, char *namep,
                                                       int nargs, va_dcl, ...) {
va_list        ap;
long*          p;
int            pid;               /* stores new process id    */
struct pentry* pptr;              /* pointer to proc. table entry */
int            i;                 /* loop variable        */
int*           currdevs;          /* current device table     */
int            dev;               /* device number for stdio  */
char*          saddr;             /* start of stack address   */
int*           sp;                /* stack pointer        */
long*          spl;
int            ps;                /* saved processor status   */
XBLOCK*        xbp;               /* stack adjustment     */
word           npara;             /* no. of stack paragraphs  */
int            die();             /* execute upon process term.   */

  disable(ps);
    va_start(ap); ssize = roundp(ssize);

    if (ssize < MINSTK)
      ssize = MINSTK;
      if (priority < 1 || (pid = newpid()) == SYSERR ||
                ((saddr = getstk(ssize)) == NULL)) {restore(ps); return SYSERR;}

    numproc++; pptr = &proctab[pid];

    pptr->ssize = ssize; pptr->pstate = PRSUSP; pptr->pimmortl = TRUE;
    for (i = 0 ; i < PNMLEN ; i++) pptr->pname[i] = (*namep ? *namep++ : ' ');
    pptr->pname[PNMLEN] = '\0';

    pptr->pprio = priority; pptr->pwaitret = 0;
    pptr->phasmsg = FALSE;                    /* no message           */
    pptr->pimmortl = FALSE;                   /* not immortal         */
    pptr->pnxtkin = BADPID;                   /* no next-of-kin       */
    pptr->pglob = NULLPTR;                    /* no global environment    */
    pptr->pbase = saddr;
    pptr->plen = ssize;
    npara = ssize>>4;                         /* convert to a paragraph count */
    pptr->pmlist = seg(saddr);                /* stack is only allocated mem. */
    xbp = (XBLOCK *)saddr;
    xbp->xbback = pptr->pmlist;               /* points to tail of list   */
    xbp->xbfore = pptr->pmlist;               /* circular list        */
    xbp->xblen = npara;
    pptr->pmalloc = npara;                    /* no. of allocated paragraphs  */
    pptr->ptarg = 0;
    pptr->oldtime = 0;                        /* resched hasn't run it yet */
    pptr->time = 0;                           /* clear CPU time used */
    pptr->ptfn = die;                         /* initialize trap to die   */
    pptr->phastrap = FALSE;                   /* no trap yet          */
    currdevs = proctab[currpid].pdevs;        /* parent device table  */

    /* new process inherits open I/O devices of parent */

    for (i=0 ; i<Nsio ; i++) {
      dev = open(currdevs[i], NULLPTR, 0);
      pptr->pdevs[i] = isbaddev(dev) ? BADDEV : dev;
      }

    pptr->pimmortl = FALSE;                   /* back to normal       */
    sp = (int*) (saddr + ssize);              /* simulate stack pointer   */
    sp -= 16;                                 /* a little elbow room      */

    pptr->pargs = nargs;

    spl = (long*) sp; spl = (long*) ((long) spl & 0xfffffffeL);

    if (nargs) {

      p = (long*) &va_arg(ap, long*) + nargs;

      /* machine dependent; copy args onto created process' stack */

      for (; nargs > 0; nargs--) *--spl = *--p;
      }

    *--spl = (long) INITRET;                  /* push on ret addr     */
    *--spl = (long) procaddr;                 /* simulate a context switch    */

    sp = (int*) spl;
    --sp ;                                    /* 1 word for bp        */
    *(--sp) = INITF;                          /* FLAGS value          */
    sp -= 2;                                  /* 2 words for si and di    */
    pptr->pregs = (char*) sp;                 /* save for context switch  */
    pptr->paddr = (Fptr) procaddr;

  restore(ps); return(pid);
  }

/*------------------------------------------------------------------------
 *  newpid  --  obtain a new (free) process id
 *-----------------------------------------------------------------------*/

LOCAL newpid(void) {
    int pid;                    /* process id to return     */
    int i;

    for (i=0 ; i<NPROC ; i++) { /* check all NPROC slots    */
        if ( (pid=nextproc--) <= 0)
            nextproc = NPROC-1;
        if (proctab[pid].pstate == PRFREE)
            return(pid);
    }
    return(SYSERR);
}
