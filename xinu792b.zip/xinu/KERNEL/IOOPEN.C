/* ioopen.c - ioopen */

#include <conf.h>
#include <kernel.h>
#include <io.h>


/*------------------------------------------------------------------------
 *  ioopen  --  return descriptor iff name is null
 *-----------------------------------------------------------------------*/

int ioopen(struct devsw* devptr, char* name, char* mode) {
    mode = mode;
    return ( (name == NULLPTR || *name == NULLCH) ? devptr->dvnum : SYSERR);
    }
