/* fprintf.c - fprintf */


#include <conf.h>
#include <kernel.h>
#include <io.h>


/*------------------------------------------------------------------------
 *  fprintf  --  print a formatted message on specified device (file)
 *-----------------------------------------------------------------------*/

int fprintf(int dev, va_dcl, ...) {
va_list ap;
char*   fmt;

  va_start(ap); fmt = va_arg(ap, char*);

  _doprnt(fmt, &va_arg(ap, long), putc, dev); return OK;
  }
