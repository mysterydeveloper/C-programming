/* fgets.c - fgets */

#include <conf.h>
#include <kernel.h>
#include <io.h>


/*------------------------------------------------------------------------
 *  fgets  --  read a newline-terminated string from device (file) dev
 *-----------------------------------------------------------------------*/

char* fgets(int dev, char* s, int n) {
register c;
register char* cs = s;

  while (--n > 0 && (c = getc(dev)) >= 0) {*cs++ = c; if (c == '\n') break;}

  if (c < 0 && cs == s) return NULLPTR;

  *cs++ = '\0'; return s;
  }
