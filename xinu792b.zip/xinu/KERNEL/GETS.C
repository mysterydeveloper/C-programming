/* gets.c - gets */

#include <conf.h>
#include <kernel.h>
#include <io.h>


#define CONSOLE 0
#define EOFChar '\004'      /* control-d is end-of-file     */

/*------------------------------------------------------------------------
 *  gets  -- gets string from the console device reading to user buffer
 *------------------------------------------------------------------------
 */
char* gets(char* s) {
    register c;
    register char *cs;

    cs = s;
        while ((c = getc(CONSOLE)) != '\n' && c != '\r' && c != EOFChar)
        *cs++ = c;
    if (c==EOFChar && cs==s)
        return(NULLPTR);
    *cs++ = '\0';
    return(s);
}
