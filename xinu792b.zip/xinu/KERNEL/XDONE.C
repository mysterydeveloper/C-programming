/* xdone.c - xdone */

#include <conf.h>
#include <kernel.h>
#include <dos.h>
#include <pc.h>
#include <proc.h>
#include <io.h>
#ifdef Ndsk
#include <disk.h>
#endif
#include <tty.h>


extern char* memptr;
extern int   run;


/*------------------------------------------------------------------------
 *  xdone  --  print system termination message and terminate PC-Xinu
 *-----------------------------------------------------------------------*/

void xdone(void) {
int ps = ps;
int i, ret;

  #ifdef Ndsk
    for ( i=0; i<Ndsk; i++ )
        control(dstab[i].dnum,DSKSYNC); /* sync the disks   */
  #endif

  enable(); sleep(1);                 // Somehow we get here with without
                                      // interrupts enabled
                                      /* let tty output settle    */
  disable(ps);

  scrollup(sctopl, scbotr, 0, 7);     /* clear the screen     */

  for ( i=0 ; i<NDEVS ; i++) {
    ret = init(i,0);                  /* un-initialize device */

    if (ret != OK) kprintf("xdone: error un-initializing device %d\n", i);
  }

  kprintf("\n\n-- system halt --\n\n");

  if (numproc == 0)
       kprintf("All user processes have completed\n");
  else kprintf("PC XINU 7.9 terminated with %d process%s active\n",
                                             numproc, numproc == 1 ? "" : "es");
  kprintf("Returning to DOS . . .\n\n");

  /* restore IRQs, return malloced memory, kill the NULL process */

  disable(ps); maprestore(); free(memptr); run = FALSE;
  }
