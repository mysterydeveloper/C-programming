/* getss.c -- get_cur_ss    get the current stack dimensions   */

/*          ** call only with ints disabled **                 */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <dos.h>


int get_cur_ss()
{
long curr_stk;
long proc_stk_base;
long proc_stk_top;

curr_stk = (long) sys_getstk();
proc_stk_base = (long) proctab[currpid].pbase;
proc_stk_top  = (long) proctab[currpid].pbase + proctab[currpid].ssize;

if ((curr_stk < proc_stk_base) || (curr_stk > proc_stk_top))
    return 0;
else
    return 1;
}
