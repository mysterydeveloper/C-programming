/* fputs.c - fputs */

#include <kernel.h>

/*------------------------------------------------------------------------
 *  fputs  --  write a null-terminated string to a device (file)
 *-----------------------------------------------------------------------*/

SYSCALL fputs(int dev, char* s) {
register r;
register c;
int putc();

  while ((c = *s++) != 0) r = putc(dev, c);

  return r;
  }
