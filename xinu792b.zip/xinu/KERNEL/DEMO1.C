
#include "conf.h"
#include "butler.h"
#include "kernel.h"
#include "window.h"



// Local Functions

static void mvCurTo(int win, Byte row, Byte col);



int xmain(long argc, char* argv[]) {
int  win;
int  rslt    = rslt;
Cur  cur     = cur;
char ch      = ch;
char buf[10] = "zyxwvut";
int  i;

  chprio(getpid(), 10);   // change priority

  win = getdev("tty");

  rslt = open(win, "#0,0:79,24", "wht/blu");

  printf("nargs: %d", argc);

  for (i = 0; i < argc; i++) printf(" %s", argv[i]);

  mvCurTo(win, 10, 40); putc(win, 'X');

  mvCurTo(win, 15, 10); fputs(win, "abc");

  mvCurTo(win, 0, 0);   write(win, buf, 4);

  mvCurTo(win, 24, 0);  printf("press return to continue "); ch = getc(win);

  sendf(butlerpid, MSGKILL); return 0;
  }


static void mvCurTo(int win, Byte row, Byte col) {
Cur  cur = cur;

  cur.pos.row = row; cur.pos.col = col;

  control(win, TCCurPos, cur.v, 0);
  }
