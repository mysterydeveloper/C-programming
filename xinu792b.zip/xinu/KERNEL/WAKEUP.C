/* wakeup.c - wakeup */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include <sleep.h>

/*------------------------------------------------------------------------
 *  wakeup  --  called by clock interrupt dispatcher to awaken processes
 *-----------------------------------------------------------------------*/

void wakeup(void) {
register int makeup = 0;              /* makeup for lost time     */
register int k;                   /* key value            */

  while (nonempty(clockq) && (k=firstkey(clockq)) <= makeup)
                                        {makeup -= k; ready(getfirst(clockq));}

  slnempty = nonempty(clockq);

  if (slnempty) {sltop = &firstkey(clockq); *sltop -= makeup;}

  resched();
  }
