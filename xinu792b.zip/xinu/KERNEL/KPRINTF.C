/* kprintf.c - kprintf */

#include <conf.h>
#include <kernel.h>
#include <io.h>
#include <tty.h>
//#include <vidio.h>
#include <varargs.h>


/*------------------------------------------------------------------------
 *  kprintf  --  kernel printf: formatted, unbuffered output to the screen
 * Derived by Bob Brown, Purdue U.
 *-----------------------------------------------------------------------*/

int kprintf(va_dcl, ...) {
int     pcx;
va_list ap;
char*   fmt;

  xdisable(pcx); va_start(ap); fmt = va_arg(ap, char*);

  _doprnt(fmt, &va_arg(ap, long), kputc, CONSOLE);
  xrestore(pcx);
  return(OK);
  }
