/* dfckmd.c - dfckmd */

#include <conf.h>
#include <kernel.h>
//#include <disk.h>
#include <file.h>
#include <mffile.h>

/*------------------------------------------------------------------------
 *  dfckmd  --  parse file mode argument and generate actual mode bits
 *-----------------------------------------------------------------------*/
int dfckmd(char* mode) {
    int mbits;
    char    ch;

    mbits = 0;
    while ((ch = *mode++) != 0)
        switch (ch) {

        case 'r':
            if (mbits&FLREAD)
                return(SYSERR);
            mbits |= FLREAD;
            break;

        case 'w':
            if (mbits&FLWRITE)
                return(SYSERR);
            mbits |= FLWRITE;
            break;

        case 'o':
            if (mbits&FLOLD || mbits&FLNEW)
                return(SYSERR);
            mbits |= FLOLD;
            break;

        case 'n':
            if (mbits&FLOLD || mbits&FLNEW)
                return(SYSERR);
            mbits |= FLNEW;
            break;

        case 'b':
            if (mbits&FLBINARY)
                return(SYSERR);
            mbits |= FLBINARY;
            break;

        default:    return(SYSERR);
        }
    if ((mbits & FLREAD) == (mbits & FLWRITE))  /* default: allow R + W */
        mbits |= (FLREAD|FLWRITE);
    return(mbits);
}
