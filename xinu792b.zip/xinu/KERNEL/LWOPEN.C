/* lwopen.c - lwopen */

#include <conf.h>
#include <kernel.h>
#include <tty.h>

/*------------------------------------------------------------------------
 *  lwopen  --  accept an open call on an already open logical window
 *------------------------------------------------------------------------
 */
int lwopen(struct devsw* devptr, char* name, char* mode) {
int         ps;
struct tty* ttyp;

  disable(ps);        name = name; mode = mode;

  ttyp = &tty[devptr->dvminor];

  if ( ttyp->wstate != LWALLOC ) {restore(ps); return SYSERR;}

  ttyp->ocount++;

  restore(ps); return devptr->dvnum;
  }
