/* setpdev.c - setpdev */

#include <conf.h>
#include <kernel.h>
#include <sio.h>
#include <proc.h>
#include <io.h>

/*------------------------------------------------------------------------
 *  setpdev  --  set a device entry in the process table entry
 *  pid         -- process to change
 *  siodev, dev -- device descriptor to set
 *-----------------------------------------------------------------------*/

SYSCALL setpdev(int pid, int siodev, int dev) {
int minor, *pdev;
int ps;

  disable(ps);

  if (isbadpid(pid)    || proctab[pid].pstate == PRFREE            ||
      isbaddev(siodev) || (minor = devtab[siodev].dvminor) >= Nsio ||
      siodev != sio[minor]
      ) {restore(ps); return SYSERR;}

  pdev = &proctab[pid].pdevs[minor]; close(*pdev);

  *pdev = isbaddev(dev) ? BADDEV : dev; restore(ps); return OK;
  }
