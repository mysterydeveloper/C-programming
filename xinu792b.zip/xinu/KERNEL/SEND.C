/* send.c - send */

#include <conf.h>
#include <kernel.h>
#include <proc.h>


static void startRcvr(int pid);


/*------------------------------------------------------------------------
 *  send  --  send a message to another process
 *-----------------------------------------------------------------------*/

SYSCALL send(int pid, long msg) {
struct pentry* pptr;      /* receiver's proc. table addr. */
int            ps;

  disable(ps);

  if (isbadpid(pid) || (pptr = &proctab[pid])->pstate == PRFREE)
                                                  {restore(ps); return SYSERR;}

  if (pptr->phasmsg) {startRcvr(pid); restore(ps); return SYSERR;}

  pptr->pmsg = msg; pptr->phasmsg = TRUE;     /* deposit message      */

  startRcvr(pid); restore(ps); return OK;
  }


static void startRcvr(int pid) {
struct pentry* pptr = &proctab[pid];

  if (pptr->pstate == PRRECV) {ready(pid); resched();}
                                              /* if receiver waits, start it  */

  else if (pptr->pstate == PRREADY) resched();

  else if (pptr->pstate == PRTRECV) {unsleep(pid); ready(pid); resched();}
  }
