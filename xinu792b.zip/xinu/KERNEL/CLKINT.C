/* clkint.c - clkint */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <sleep.h>
#include <io.h>

extern long    ticks_10ms;    /* counts in 100ths of second 0-INF  */


/*------------------------------------------------------------------------
 *  clkint  --  clock service routine
 *  called at every clock tick and when starting the deferred clock
 * mdevno -- minor device number
 *-----------------------------------------------------------------------*/

INTPROC clkint(int mdevno) {
static int clkinc   = 0;
static int clkinc10 = 0;

    mdevno = mdevno; tod += 5;

    if ((clkinc10 += 591) >= 1200) {ticks_10ms = tod++; clkinc10 -= 1200;}

    /* Notes on the above: this int is executed about 18.2 times per second.
         After 18 ints, tod=90 but the elapsed time is .9886572 secs. Every so
         often, the if statement above increments tod to make up the lag. Tod
         thus represents the time since startup in hundredths of a second. */

    if ((clkinc += TICSD) >= TICSN) {clktime++; clkinc -= TICSN;}

    if (defclk) {clkdiff++; return OK;}

    if (slnempty) if (-- *sltop <= 0) wakeup();

    if (--preempt <= 0) resched();

    return OK;
    }
