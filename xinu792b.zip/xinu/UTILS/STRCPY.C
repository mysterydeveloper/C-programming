/* Copy string s2 to s1.  s1 must be large enough.
 * return s1 */


#include <utils.h>


char* strcpy(char* s1, char* s2) {
register char *os1 = s1;

	while ((*s1++ = *s2++) != 0) ;

  return os1;
  }
