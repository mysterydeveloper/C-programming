// Simple Random Number Generator


static long randx = 1;


void srand(unsigned x) {randx = x;}


int rand(void) {
  randx = randx * 1103515245L + 12345L;

  return (int) (randx >> 16) & 077777;
  }
