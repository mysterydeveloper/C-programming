/*
 *  sakura.h - header file for sakura.c
 */
// include this file only once
// if a const __SAKURA_H is not defined, 
// then the file is compiled

#ifndef __SAKURA_H
#define __SAKURA_H


#include <stdio.h>
#include <stdlib.h>

#define FILENAME "test.txt"
#define WRITEMODE "w"
#define READMODE "r"

#define MAX_COUNT 200

#define DEBUG


void readContents();



#endif