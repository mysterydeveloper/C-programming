/*
 *  create a new project and add a source c file to it.
 *  don't care what you call it :)
 *  back in a minute
 */ 

#include "sakura.h"

	// open a file, write to it, close it.
main()
{
	FILE *fptr;

	// open file
	fptr = fopen(FILENAME, WRITEMODE);
	if( fptr == NULL )
	{
		printf("\n\n\tCould not open file\n");
		system("pause");
		exit(0);
	}
	// write to the file
	fprintf(fptr, "Hello file world!!!");

	// close the file
	fclose(fptr);

	printf("\n\n\nRead the file\n");
	system("pause");
	// read the contents of the file.
	readContents();


	printf("\n\n\n");
	system("pause");
} // end of main

void readContents()
{
	FILE *fptr;
	int i = 0;
	char strBuffer[MAX_COUNT + 1];	// +1 accounts for \0
									// null character

#ifdef DEBUG
	printf("\nreadContents: \n%s, \n%d", __FILE__, __LINE__);
#endif

	fptr = fopen(FILENAME, READMODE);
	if( fptr == NULL )
	{
		printf("\n\nCould not open file %s", FILENAME);
		system("pause");
		exit(0);
	}

	do // read all the lines in the file.
	{
		fgets(strBuffer, MAX_COUNT, fptr);
		printf("\nLine %d: %s", ++i, strBuffer);
	} while( !feof(fptr) );	// haven't reached end of file

	// then close the file
	fclose(fptr);
} // end readContents