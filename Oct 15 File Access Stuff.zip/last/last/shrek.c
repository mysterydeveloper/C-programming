/*
 * shrek.c - file stuff today
 *			read and write from and to files
 */

#include "shrek.h"	// "" instead of <>

	// open a file, write to a file, read from a file, close file
main()
{
	FILE *fptr;		// create a file pointer.

	fptr = fopen(FILENAME, WRITEMODE);
	if( fptr == NULL )
	{
		printf("\nCould not open %s.", FILENAME);
		system("pause");
		exit(0);
	}

	fprintf(fptr, "Hello file world!!!\n");
	fprintf(fptr, "hope this works");
	fclose(fptr);
	
#ifdef DEBUG
	printf("\nfrom Main: %s, %d", __FILE__, __LINE__);
#endif

	readContents(); // declare in the header file

	printf("\n\n\n");
	system("pause");
} // end of main

void readContents()
{
	FILE *fptr;
	int i = 0;
	char strBuffer[MAX_COUNT + 1]; // +1 for null character '\0'

	
	fptr = fopen(FILENAME, READMODE); // READMODE = "r"
	if( fptr == NULL )	// copied from main function
	{
		printf("\nCould not open %s.", FILENAME);
		system("pause");
		exit(0);
	}

	do
	{
		// read contents
		fgets(strBuffer, MAX_COUNT, fptr);
		printf("\nLine %d: %s", ++i, strBuffer);
	}while( !feof(fptr) );	// haven't reached end of file (eof)

	fclose(fptr);


} // end readContents