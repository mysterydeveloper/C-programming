/*
 * shrek.h - header file for shrek.c
 */

#ifndef __SHREK_H
#define __SHREK_H

#include <stdio.h>
#include <stdlib.h>

// uncomment next line for debug version
//#define DEBUG

#define FILENAME "jargon.txt" // constant value
#define WRITEMODE "w"
#define READMODE "r"

#define MAX_COUNT 200

void readContents();

#endif // end #ifndef __SHREK_H