#include "shrek.h"


void doStuff()
{
	printf("\nfrom doStuff: %s, %d", __FILE__, __LINE__);
	readContents();

}