/*
 * gerbil.c - filestuff today
 *			write to a file
 */

#include "gerbil.h"	// include header file.
					// note the "" instead of <>



main()
{
	FILE *fptr;	// declare a pointer to a file
				// sometimes called a file handle


	fptr = fopen(FILE_NAME, "w");
	if( fptr == NULL )
	{
		printf("\n\n\tFile could not be opened");
		system("pause");
		exit(0);		// doesn't open, then exit
	}
	else
	{
		fprintf(fptr, "Hello file world!!!");
		fclose(fptr);
	}

	readFileContents();

	printf("\n\n\n");
	system("pause");
} // end of main

void readFileContents()
{
	FILE *fptr;
	int i = 0;
	char strBuffer[MAX_COUNT+1];	// +1 for the \0
									// null character
#ifdef DEBUG
	fptr = fopen("trace.txt", "a");
	fprintf(ftpr, "\nReadFileContents, %s, %d", __FILE__, __LINE__);
	fclose(fptr);
#endif

	fptr = fopen(FILE_NAME, "r");
	if( fptr == NULL )
	{
		printf("\n\n\tCould not open file for reading");
	}
	else
	{
		// read the contents of the file.
		do
		{
			fgets(strBuffer, MAX_COUNT, fptr);
			printf("\nLine %d: %s", ++i, strBuffer);		
		}while( !feof(fptr) );
		// while (! f. end of file(fptr))

		
		
		
		printf("\n\n\n");
		system("pause");
		fclose(fptr);
	}

} // end readFileContents();

