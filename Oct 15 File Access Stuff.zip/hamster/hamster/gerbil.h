/*
 *	gerbil.h - header file for gerbil.c
 */

#ifndef __GERBIL_H__
#define __GERBIL_H__


#include <stdio.h>
#include <stdlib.h>

#define FILE_NAME "hello.txt"
#define MAX_COUNT 255

// uncomment nextline for debug version of code
//#define DEBUG

void readFileContents();

#endif
