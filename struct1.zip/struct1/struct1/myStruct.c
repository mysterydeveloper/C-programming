/*
 * structure stuff
 */

#include <stdio.h>
#include <stdlib.h>

#define MAX_LEN 16

// declare a structure 
// similar to class definition
struct myDogs {
				char breedName[MAX_LEN+1];
				char breedSize[MAX_LEN+1];
				char breedExercise[MAX_LEN + 1];
				int breedLifeExpext;
};

// declare functions
void createOneDog(struct myDogs *);
void outputDetails(struct myDogs *);

main()
{
	// declare a variable for struct myDogs
	// variable is called oneDog
	// variable type is struct myDogs
	struct myDogs oneDog, twoDog;

	createOneDog(&oneDog);
	createOneDog(&twoDog);

	outputDetails(&oneDog);
	outputDetails(&twoDog);


	printf("\n\n\n");
	system("pause");
} // end main

void createOneDog(struct myDogs *tempDog)
{

	
	printf("\nEnter a breed of dog: ");
	fflush(stdin);
	gets(tempDog->breedName);

	printf("\nWhat size is the dog? ");
	fflush(stdin);
	gets(tempDog->breedSize);

	printf("\nWhat level of exercise is required: ");
	fflush(stdin);
	gets(tempDog->breedExercise);

	printf("\nwhat is the general life expectancy? ");
	fflush(stdin);
	scanf("%d", &tempDog->breedLifeExpext);


} // end createOneDog

void outputDetails(struct myDogs *temp)
{
	printf("\nThe dog %s is a %s breed and has a exercise level of %s.",
				temp->breedName, 
				temp->breedSize, 
				temp->breedExercise );
	printf("\nThe average life expectancy for a %s is %d years.",
				temp->breedName, temp->breedLifeExpext );


}
