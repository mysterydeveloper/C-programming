/*
 * structure stuff
 */

#include <stdio.h>
#include <stdlib.h>

#define MAX_LEN 40

// create structure for films
struct myFilms{
				char title[MAX_LEN + 1];
				char starring[MAX_LEN + 1];
				int rating;
			};

// declare functions
void InputFilms(struct myFilms *);
void OutputFilms(struct myFilms *);

main()
{
	// declare a variable called oneFilm
	// variable type is struct myFilms
	struct myFilms oneFilm, twoFilm;

	// Input
	InputFilms(&oneFilm);
	InputFilms(&twoFilm);
	// end Input

	// Output
	OutputFilms(&oneFilm);
	OutputFilms(&twoFilm);
	// end Output

	printf("\n\n\n");
	system("pause");
} // end main

void InputFilms( struct myFilms *tempFilm)
{
	printf("\nEnter a title: ");
	fflush(stdin);
	gets(tempFilm->title ); // when using pointers
							// use the -> instead
							// of the .

	printf("\nEnter the lead actor/actress: ");
	fflush(stdin);
	gets(tempFilm->starring );

	printf("\nEnter a rating (1-5): ");
	fflush(stdin);
	scanf("%d", &tempFilm->rating );

} // end InputFilms

void OutputFilms(struct myFilms *tempFilm)
{
	printf("\nThe film \"%s\" stars %s.",
				tempFilm->title,
				tempFilm->starring );
	printf("\nOn a scale of 1-5, it scored %d", tempFilm->rating);

}
