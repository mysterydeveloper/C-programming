/*
 * structure stuff
 *
 *	what is the difference between 
 *		pass by value and pass by reference?
 *
 *		pass by value - pass a copy of the data to the function
 *						A change in the function does not affect
 *						the original
 *		pass by reference - pass the memory address of the data
 *							to the function
 *							A Change in the function is a change
 *							to the original data
 */

#include <stdio.h>
#include <stdlib.h>

#define MAX_LEN 15

// variable type is struct myCars
struct myCars
{
	char manufacturer[MAX_LEN + 1];	// 16 chars
	char model[MAX_LEN + 1];	// 16 chars (16 * 1 byte)
	int price;					// 4 bytes
							// total of 36 bytes
};

/*
  pass by value requires 36 bytes
  pass by reference requires 4 bytes
 */


// pass a pointer to Struct myCars variable
void InputFunction(struct myCars *);
void OutputFunction(struct myCars *);

main()
{
	// declares a variable called oneCar of type 
	// struct myCars
	struct myCars oneCar, twoCar;

	// input
	InputFunction(&oneCar);
	InputFunction(&twoCar);

	/* output */
	OutputFunction(&oneCar);
	OutputFunction(&twoCar);

	printf("\n\n\n");
	system("pause");
} // end main

void InputFunction(struct myCars *tempCar)
{
	
	printf("\nEnter a manufacturer: ");
	fflush(stdin);
	gets(tempCar->manufacturer);

	printf("\nEnter a model: ");
	fflush(stdin);
	gets(tempCar->model );

	printf("\nEnter a price: ");
	fflush(stdin);
	scanf("%d", &tempCar->price );

} // end InputFunction

void OutputFunction(struct myCars *tempCar)
{
	printf("\nThe car %s by %s costs %d.", 
				tempCar->model,
				tempCar->manufacturer,
				tempCar->price );

}
