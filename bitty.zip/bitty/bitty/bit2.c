/*
    bit 2 brutus
 */

#include <stdio.h>
#include <stdlib.h>

#define MAX 50

void convertUp(char *);

main()
{
	char myString[MAX];
	
	printf("\nEnter string: ");
	gets(myString);
	printf("\nString is : %s", myString);
	convertUp(myString);
	printf("\nUpper String is : %s", myString);
	printf("\n\n\n\n");
	system("pause");
} // end main

void convertUp(char *str)
{
	// loop through the characters of the string
	// convert each to uppercase using AND
	// AND them with 0xDF 11011111b
	// until reach '\0'
	int i = 0;

	while( str[i] != '\0')
	{
		if (str[i] != ' ')	// not a space
		{
			str[i] &= 0xDF;
		}
		i++;
	}


	// while( (str[i++] &= 0xDF) != '\0')

} // end convert
