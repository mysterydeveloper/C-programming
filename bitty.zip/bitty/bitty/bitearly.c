/*
	bit stuff

 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX 50

void convertUp(char *);

main()
{
	char myStr[MAX];

	printf("\nEnter string: ");
	gets(myStr);

	printf("\n\nString: %s", myStr);
	convertUp(myStr);
	printf("\n\nString: %s", myStr);

	printf("\n\n\n");
	system("pause");
} // end main

void convertUp(char *str)
{
	// loop through the string until the end
	// set the bits using the mask and the AND
	// set bit 5 to 0, leave the others
	// hex DF     1101 1111
	int i = 0;
	
	//while( (str[i++] &= 0xDF) != '\0');

	// space = 0x20 = 00100000
	//         0xDF = 11011111
	// AND result   = 00000000

	while( str[i] != '\0')
	{
		if( (str[i] != ' ') &&
			(!ispunct(str[i]) ) )	 // include ctype.h
		{
			str[i] &= 0xDF;
		}
		i++;
	}


} // end convertUP
