/*
  bit stuff - AND OR NOT
 */

#include <stdio.h>
#include <stdlib.h>

#define MAX 50

void convertToUpper(char *);

main()
{
	char myString[MAX];

	printf("\nEnter a string: ");
	gets(myString);

	printf("\n\nString is: %s ", myString);
	convertToUpper(myString);
	printf("\n\nUpper string is: %s ", myString);

	printf("\n\n\n");
	system("pause");
} // end main

void convertToUpper( char *str)
{
	// convert using bitwise AND
	// bit 6 on uppercase is always 1
	// bit 6 on lowercase is always 0
	// convert from l -> u by setting bit 6 to 1 with AND
	// write a while loop to go through the string
	// AND each letter with 0xDF (1101 1111)
	int i = 0;

	printf("\n\n");

	while(str[i] != '\0')
	{
		printf("%c", str[i]);
		//str[i] = str[i] & 0xDF;
		str[i] &= 0xDF;
		i++;
	}

	
	//while( (str[i++] &= 0xDF) != '\0');



} // end convert


