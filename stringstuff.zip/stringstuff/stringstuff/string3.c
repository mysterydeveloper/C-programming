/*
 * string stuff
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 85

int strLength(char *);	// takes char buffer as param

main()
{
	char inStr[MAX + 1];
	char copyStr[MAX + 1];
	int len;

	printf("\nEnter a string: ");
	fflush(stdin);
	gets(inStr);

	len = strLength(inStr);
	printf("\nString is %d chars long", len);

	len = strlen(inStr); // from string.h
	printf("\nString is %d chars long", len);

	//strcpy(copyStr, inStr);
	//copyStr[strlen(copyStr)] = '\0';

	//printf("\ncopied string %s", copyStr);

	printf("\nEnter a string to search with: ");
	fflush(stdin);
	gets(copyStr);

	if( strstr(inStr, copyStr) != NULL)
	{
		printf("\nFound string : %s", 
					strstr(inStr, copyStr) );
	}
	else
	{
		printf("\nstring not found");
	}

	printf("\n\n\n");
	system("pause");
} // end main

int strLength(char *tmp)
{
	int i = 0;
	while( tmp[i++] != '\0' );
	return(i-1);
} // end strLength