/*
 * string stuff for wednesday :)
 * take in string, calculate length.
 * string in c similar to string in java
 * set counter= 0 at start, increment when 
 * not = '\0', return the answer.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int strLength(char *);
void compareStrings();

#define MAX 85

void oldmain();

void oldmain()
{
	char inStr[MAX + 1];
	int l;

	printf("\nEnter a string: ");
	gets(inStr);

	l = strLength(inStr);
	printf("\nstring id %d chars.", l);
	l = strlen(inStr); // from string.h
	printf("\nstrlen is %d", l);

	compareStrings();

	printf("\n\n\n");
	system("pause");
} // end main

int strLength(char *tempStr)
{
	int i = 0;
	while(tempStr[i++] != '\0');
	// same as
	//while( tempStr[i] != '\0')
	//{
	//	i++;
	//}
	return(i - 1); // take off the \0 at end
} // end strLength

void compareStrings()
{
	char str1[MAX + 1], str2[MAX + 1];
	int ret;
	printf("\nEnter string 1: ");
	fflush(stdin);
	gets(str1);

	printf("\nEnter string 2: ");
	fflush(stdin);
	gets(str2);

	ret = strcmp(str1, str2);
	if(ret < 0)
   {
      printf("str1 is less than str2");
   }
   else if(ret > 0) 
   {
      printf("str1 is greater than str2");
   }
   else 
   {
      printf("str1 is equal to str2");
   }

} // end compareStrings