/*
 * string stuff
 * function to get length of string
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 85

int lenString(char *);

main()
{
	char *strPtr;
	char newString[MAX + 1];
	char toString[15+1];
	int length = 0;

	printf("\n\nEnter a string => ");
	gets(newString);

	printf("\n\nEnter a string => ");
	gets(toString);
	
	printf("\nConcatenating :%s: to :%s:", newString,
										toString);

	strcat(toString, newString);
	printf("\nResult is :%s:", toString);
	printf("\nnewString is :%s:", newString);

	// newString = &newString[0]
	length = lenString(&newString[0]);
	printf("\n length of string is %d chars.", length);

	printf("\n length is %d", strlen(newString));

	printf("\n\n\n");
	system("pause");
} // end main

int lenString(char *findLen)
{
	int i = 0;

	while(findLen[i++] != '\0'); 

	// rewrite as
	//while(findLen[i] != '\0')
	//{
	//	i++;
	//}

	return(i-1);

} // end lenString